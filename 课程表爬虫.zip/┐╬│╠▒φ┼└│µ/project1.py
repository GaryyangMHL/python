import requests
from bs4 import BeautifulSoup
session = None
checkcodePath='./code.png'
res = requests.Session()
Origin_url = "http://zfxk.hhit.edu.cn/(0gwzcb455tgoawyqcgqdi4up)/"
url = "http://zfxk.hhit.edu.cn/(0gwzcb455tgoawyqcgqdi4up)/default2.aspx"
checkcodeURL = Origin_url+'CheckCode.aspx'  #验证码网址
head = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36",   "Referer":"http://zfxk.hhit.edu.cn/(0gwzcb455tgoawyqcgqdi4up)/default2.aspx"}
#head_login = {"Content-Length":"189","Cache-Control":"max-age=0","Upgrade-Insecure-Requests":"1","User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36","Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","Accept-Language":"zh-CN,zh;q=0.9","Referer":"http://zfxk.hhit.edu.cn/(0gwzcb455tgoawyqcgqdi4up)/default2.aspx"}
post_data = {"__VIEWSTATE":"viewstate","txtUserName" : "" ,"TextBox2":"","txtSecretcode":"" ,"RadioButtonList1":"%D1%A7%C9%FA","Button1":"","lbLanguage":"","hidPdrs":"","hidsc":""}


proxies={
'http': 'http://127.0.0.1:8080',
'https': 'https://127.0.0.1:8080',
}


def get_viewstate(url):
    html = res.get(url)
    viewstate = BeautifulSoup(html.text, "lxml").find("input")["value"]
    return viewstate

def get_photo(URL):
    checkcode = res.get(checkcodeURL, headers=head)
    with open(checkcodePath,'wb') as fp: #保存验证码图片
        fp.write(checkcode.content)

    post_data['txtSecretcode']=input("请输入图中的验证码:(保存在同级文件下):");

def login():
    user_name=input("请输入学号:")
    user_password=input("请输入您的密码:")
    viewstate=get_viewstate(url)
    post_data["txtUserName"]=user_name
    post_data["TextBox2"]=user_password
    post_data["__VIEWSTATE"]=viewstate
    login_page_url=Origin_url+"default2.aspx"
    head['Referer']=login_page_url
    get_photo(url)
    homePage = res.post(login_page_url, data=post_data,headers=head)  #在这里得到了主页面
    with open('text1.html','w' , encoding = 'gb2312') as f :
           f.write(homePage.text)
           if()
    #更改数据
    #head["Referer"]="http://zfxk.hhit.edu.cn/(0gwzcb455tgoawyqcgqdi4up)/default2.aspx"
    exit_sys = "what should i do "
    URL = "http://zfxk.hhit.edu.cn/(0gwzcb455tgoawyqcgqdi4up)/xskbcx.aspx?xh="+user_name+"&xm=%C1%F5%D3%EE&gnmkdm=N121603 "
    #URL = GET /(0gwzcb455tgoawyqcgqdi4up)/xskbcx.aspx?xh=2018123186&xm=%B9%A8%EC%CF%D1%F4&gnmkdm=N121603 HTTP/1.1
    head["Referer"]= URL
    
    page_home=res.get(URL,headers=head )
    post_data["__EVENTTARGET"]="xqd" 
    while exit_sys != "q":
        # query_years = input("请输入您要查询课表的年份:")
        # query_how = input("请输入您要查询第几学期的课表：")
        # post_data["xnd"]= query_years
        # post_data["xqd"]=query_how
        learning = res.post(URL  , headers = head)
        print(URL)
        with open( '课程表'+ '-'+ '.html'  ,'w' , encoding = "gb2312") as f :
                   f.write(page_home.text)
        # if query_years == "2019-2020" and query_how == "1" :
        #         with open( query_years + '-'+ query_how + '.html'  ,'w' , encoding = "gb2312") as f :
        #            f.write(page_home.text)
        # else : 
        #         with open( query_years + '-'+ query_how + '.html'  ,'w' , encoding = "gb2312" , errors = "ignore") as f :
        #            f.write( learning.text)
        print("您的课表已经保存为html的形式！")
        print("按q退出 按c继续")
        while 1 :
            exit_sys = input()
            if exit_sys == "c" or exit_sys == 'q' :
                break
            else:
                print("无效操作！")
    return learning


def class_table(table_html):
      pass 
    

def main():
    res = login() 
    class_table(res)
if __name__ == "__main__":
    main() 